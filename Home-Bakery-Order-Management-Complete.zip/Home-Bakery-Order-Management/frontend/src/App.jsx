import { useEffect, useMemo, useState } from "react";
import axios from "axios";

const API = "http://localhost:8080/api";

const initialForm = {
  customerName: "",
  phone: "",
  address: "",
  deliveryDate: "",
  customization: "",
  quantity: 1
};

function App() {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [order, setOrder] = useState(null);
  const [form, setForm] = useState(initialForm);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    axios.get(`${API}/products`)
      .then(response => setProducts(response.data))
      .catch(() => setError("Cannot connect to Spring Boot. Make sure the backend is running on port 8080."))
      .finally(() => setLoading(false));
  }, []);

  const total = useMemo(() => {
    if (!selectedProduct) return 0;
    return selectedProduct.price * Number(form.quantity || 1) + 50;
  }, [selectedProduct, form.quantity]);

  const updateForm = (field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const submitOrder = async (event) => {
    event.preventDefault();
    setError("");

    if (!selectedProduct) return;

    try {
      const response = await axios.post(`${API}/orders`, {
        customerName: form.customerName,
        phone: form.phone,
        address: form.address,
        deliveryDate: form.deliveryDate,
        customization: `${selectedProduct.name}: ${form.customization}`,
        quantity: Number(form.quantity),
        totalAmount: total
      });

      setOrder(response.data);
    } catch (err) {
      const serverMessage = err.response?.data?.message;
      setError(serverMessage || "Order could not be placed. Check the backend and database.");
    }
  };

  const reset = () => {
    setSelectedProduct(null);
    setOrder(null);
    setForm(initialForm);
    setError("");
  };

  return (
    <div className="app">
      <header className="hero">
        <nav className="navbar">
          <h1>🧁 Sweet Home Bakery</h1>
          <span>Freshly baked with love ❤️</span>
        </nav>

        <div className="hero-content">
          <p className="eyebrow">HOME BAKERY • CUSTOM ORDERS</p>
          <h2>Make every celebration sweeter.</h2>
          <p>
            Fresh cakes, cupcakes, brownies and cookies made for your special moments.
          </p>
          <a href="#products" className="hero-button">Explore Menu</a>
        </div>
      </header>

      <main>
        {error && <div className="alert">{error}</div>}

        <section id="products" className="section">
          <div className="section-heading">
            <p className="eyebrow">OUR MENU</p>
            <h2>Best Sellers</h2>
          </div>

          {loading ? (
            <div className="loading">Loading delicious products...</div>
          ) : products.length === 0 ? (
            <div className="empty">No products found. Add products to the database.</div>
          ) : (
            <div className="product-grid">
              {products.map(product => (
                <article className="product-card" key={product.id}>
                  <img src={product.imageUrl} alt={product.name} />
                  <div className="product-body">
                    <span className="badge">{product.category}</span>
                    <h3>{product.name}</h3>
                    <p>{product.description}</p>

                    <div className="product-footer">
                      <strong>₹{product.price}</strong>
                      <button onClick={() => {
                        setSelectedProduct(product);
                        setOrder(null);
                        setError("");
                        window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
                      }}>
                        Customize & Order
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>

        {selectedProduct && !order && (
          <section className="checkout section">
            <div className="checkout-card">
              <div className="checkout-header">
                <div>
                  <p className="eyebrow">CUSTOM ORDER</p>
                  <h2>{selectedProduct.name}</h2>
                  <p>Base price: ₹{selectedProduct.price}</p>
                </div>
                <button className="secondary" onClick={reset}>Cancel</button>
              </div>

              <form onSubmit={submitOrder}>
                <div className="form-grid">
                  <label>
                    Customer Name
                    <input
                      required
                      value={form.customerName}
                      onChange={e => updateForm("customerName", e.target.value)}
                      placeholder="Enter your name"
                    />
                  </label>

                  <label>
                    Phone Number
                    <input
                      required
                      pattern="[0-9]{10}"
                      title="Enter exactly 10 digits"
                      value={form.phone}
                      onChange={e => updateForm("phone", e.target.value)}
                      placeholder="9876543210"
                    />
                  </label>

                  <label className="full">
                    Delivery Address
                    <input
                      required
                      value={form.address}
                      onChange={e => updateForm("address", e.target.value)}
                      placeholder="House number, street, city"
                    />
                  </label>

                  <label>
                    Delivery Date
                    <input
                      required
                      type="date"
                      min={new Date().toISOString().split("T")[0]}
                      value={form.deliveryDate}
                      onChange={e => updateForm("deliveryDate", e.target.value)}
                    />
                  </label>

                  <label>
                    Quantity
                    <input
                      required
                      min="1"
                      type="number"
                      value={form.quantity}
                      onChange={e => updateForm("quantity", e.target.value)}
                    />
                  </label>

                  <label className="full">
                    Customization
                    <textarea
                      value={form.customization}
                      onChange={e => updateForm("customization", e.target.value)}
                      placeholder="Example: Happy Birthday Mom, pink theme, eggless, less sugar..."
                    />
                  </label>
                </div>

                <div className="summary">
                  <span>Product: ₹{selectedProduct.price} × {form.quantity}</span>
                  <span>Home delivery: ₹50</span>
                  <strong>Total: ₹{total}</strong>
                </div>

                <button className="place-order" type="submit">
                  🎉 Place Order
                </button>
              </form>
            </div>
          </section>
        )}

        {order && (
          <section className="confirmation section">
            <div className="confirmation-card">
              <div className="success-icon">✓</div>
              <p className="eyebrow">ORDER CONFIRMED</p>
              <h2>Thank you, {order.customerName}!</h2>
              <p>Your bakery order has been received successfully.</p>

              <div className="order-box">
                <div><span>Order ID</span><strong>#{order.id}</strong></div>
                <div><span>Total</span><strong>₹{order.totalAmount}</strong></div>
                <div><span>Delivery Date</span><strong>{order.deliveryDate}</strong></div>
                <div><span>Status</span><strong>{order.status}</strong></div>
              </div>

              <div className="tracking">
                <div className="done">✓ Order Placed</div>
                <div>○ Confirmed</div>
                <div>○ Preparing</div>
                <div>○ Ready</div>
                <div>○ Out for Delivery</div>
                <div>○ Delivered</div>
              </div>

              <button onClick={reset}>Place Another Order</button>
            </div>
          </section>
        )}
      </main>

      <footer>
        <strong>🧁 Sweet Home Bakery</strong>
        <span>Home Bakery Order Management System • PBL Project</span>
      </footer>
    </div>
  );
}

export default App;
